## Quiz Módulo 1: Entendendo a Saúde Digital

**1. O que é Saúde Digital, segundo a OMS?**  
a) Uso de prontuários eletrônicos  
b) Consultas online  
c) Campo do conhecimento e prática com tecnologias digitais para melhorar a saúde  
d) Aplicativos de celular

✅ **Resposta correta:** c

---

**2. Qual das tecnologias abaixo está associada à Saúde Digital?**  
a) Fax e papel carbono  
b) Inteligência Artificial, Big Data, IoT  
c) Impressora matricial e CD-ROM  
d) Satélite e telefone fixo

✅ **Resposta correta:** b

---

**3. Qual fator impulsionou a Saúde Digital durante a pandemia?**  
a) Aumento de leitos hospitalares  
b) Distribuição de remédios  
c) Necessidade de atendimentos remotos  
d) Fechamento das UBS

✅ **Resposta correta:** c

---

**4. Interoperabilidade significa:**  
a) Compartilhamento seguro e compreensível de dados entre sistemas  
b) Impressão de prontuários  
c) Troca de mensagens por e-mail  
d) Importação de planilhas do Excel

✅ **Resposta correta:** a

---

**5. Qual é um exemplo de aplicação prática da Saúde Digital?**  
a) Uso de drones  
b) Planejamento vacinal com dados do SISAB  
c) Impressão de cartazes  
d) Criação de grupos de WhatsApp

✅ **Resposta correta:** b

---

## Quiz Módulo 2: Governança e Estratégia de Saúde Digital
... (restante mantido no arquivo)
